// script.js

// Function to toggle the mobile menu
function toggleMenu() {
    var menu = document.getElementById("main-menu");
    menu.classList.toggle("open");
}

// Function to close the mobile menu when a menu item is clicked
function closeMenu() {
    var menu = document.getElementById("main-menu");
    menu.classList.remove("open");
}

// Function to handle smooth scrolling for anchor links
document.addEventListener("DOMContentLoaded", function() {
    var scrollLinks = document.querySelectorAll('a[href^="#"]');
    
    for (var i = 0; i < scrollLinks.length; i++) {
        scrollLinks[i].addEventListener("click", function(e) {
            e.preventDefault();

            var targetId = this.getAttribute("href").substring(1);
            var targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                var offsetTop = targetElement.offsetTop;

                window.scrollTo({
                    top: offsetTop,
                    behavior: "smooth"
                });
            }
        });
    }
});